import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';



@Component({
  selector: 'app-create-list',
  templateUrl: './create-list.component.html',
  styleUrls: ['./create-list.component.css']
})
export class CreateListComponent {

  inputTask = new FormControl();
  taskList: any = [];
  public noWhitespaceValidator(control: FormControl) {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true };
  }
  addTask() {

    const newtask = this.inputTask.value;
    this.taskList.push(newtask);

    this.inputTask.setValue('');
  }



  deltask(item) {
    this.taskList.item.remove();
  }

}

